import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/console_state.dart';
import '../widgets/channel_strip.dart';

/// VCA + POP groups with full member editing (original Mixtender 2 feature).
class VcaScreen extends StatelessWidget {
  const VcaScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<ConsoleState>();

    // If a VCA is selected for member editing, show the editor
    if (state.selectedVca >= 0 && state.selectedVca < state.vcas.length) {
      return _MemberEditor(
        title: state.vcas[state.selectedVca].name,
        members: state.vcas[state.selectedVca].members,
        onToggle: (ch) => state.toggleVcaMember(state.selectedVca, ch),
        onClose: () => state.setSelectedVca(-1),
        state: state,
      );
    }

    return Column(
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          color: const Color(0xFF0A0A12),
          child: const Text(
            'VCA Groups  ·  tap a VCA to edit members',
            style: TextStyle(fontWeight: FontWeight.w600, color: Colors.white70, fontSize: 13),
          ),
        ),
        SizedBox(
          height: 200,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            itemCount: state.vcas.length,
            itemBuilder: (context, i) {
              final v = state.vcas[i];
              return ChannelStrip(
                index: i,
                name: v.name,
                fader: v.fader,
                mute: v.mute,
                solo: v.solo,
                meter: v.meter,
                isSelected: false,
                onFaderChanged: (val) {
                  v.fader = val;
                  state.refresh();
                },
                onMute: () {
                  v.mute = !v.mute;
                  state.refresh();
                },
                onSolo: () {
                  v.solo = !v.solo;
                  state.refresh();
                },
                onSelect: () => state.setSelectedVca(i),
              );
            },
          ),
        ),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          color: const Color(0xFF0A0A12),
          child: const Text(
            'POP Groups',
            style: TextStyle(fontWeight: FontWeight.w600, color: Colors.white70, fontSize: 13),
          ),
        ),
        Expanded(
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            itemCount: state.popGroups.length,
            itemBuilder: (context, i) {
              final p = state.popGroups[i];
              return ChannelStrip(
                index: i,
                name: p.name,
                fader: p.fader,
                mute: p.mute,
                solo: p.solo,
                meter: p.meter,
                isSelected: false,
                onFaderChanged: (val) {
                  p.fader = val;
                  state.refresh();
                },
                onMute: () {
                  p.mute = !p.mute;
                  state.refresh();
                },
                onSolo: () {
                  p.solo = !p.solo;
                  state.refresh();
                },
                onSelect: () {
                  // Re-use VCA member editor pattern for POP
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('${p.name}: ${p.members.length} members')),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}

class _MemberEditor extends StatelessWidget {
  final String title;
  final List<int> members;
  final void Function(int) onToggle;
  final VoidCallback onClose;
  final ConsoleState state;

  const _MemberEditor({
    required this.title,
    required this.members,
    required this.onToggle,
    required this.onClose,
    required this.state,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
          color: const Color(0xFF1A1A2E),
          child: Row(
            children: [
              IconButton(icon: const Icon(Icons.arrow_back), onPressed: onClose),
              Text('Edit members – $title',
                  style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
              const Spacer(),
              Text('${members.length} selected',
                  style: const TextStyle(color: Colors.white54, fontSize: 12)),
            ],
          ),
        ),
        Expanded(
          child: GridView.builder(
            padding: const EdgeInsets.all(12),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4,
              childAspectRatio: 2.2,
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
            ),
            itemCount: state.inputs.length,
            itemBuilder: (context, i) {
              final selected = members.contains(i);
              final ch = state.inputs[i];
              final color = Color(channelColorPalette[ch.colorIndex]);
              return GestureDetector(
                onTap: () => onToggle(i),
                child: Container(
                  decoration: BoxDecoration(
                    color: selected ? color.withOpacity(0.25) : Colors.white10,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: selected ? color : Colors.white12,
                      width: selected ? 2 : 1,
                    ),
                  ),
                  child: Center(
                    child: Text(
                      ch.name,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: selected ? FontWeight.w600 : FontWeight.normal,
                        color: selected ? Colors.white : Colors.white60,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
