import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/console_state.dart';
import '../services/osc_service.dart';
import '../widgets/channel_strip.dart';
import 'eq_screen.dart';
import 'vca_screen.dart';
import 'geq_screen.dart';
import 'scenes_screen.dart';
import 'safety_screen.dart';

class MixScreen extends StatelessWidget {
  const MixScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<ConsoleState>();
    final osc = context.watch<OscService>();
    final model = state.model!;

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Text(model.displayName),
            const SizedBox(width: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: osc.isDemoMode
                    ? Colors.orange.withOpacity(0.2)
                    : Colors.green.withOpacity(0.2),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                osc.isDemoMode ? 'DEMO' : 'LIVE',
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  color: osc.isDemoMode ? Colors.orange : Colors.greenAccent,
                ),
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: Icon(
              state.isFlipMode ? Icons.swap_horiz : Icons.swap_horiz_outlined,
              color: state.isFlipMode ? const Color(0xFFE94560) : null,
            ),
            tooltip: 'Flip Mode',
            onPressed: () => state.toggleFlipMode(),
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Disconnect',
            onPressed: () => osc.disconnect(),
          ),
        ],
      ),
      body: Column(
        children: [
          _OverviewBar(state: state),
          _BankSelector(state: state),
          Expanded(child: _buildBody(context, state)),
          _MastersStrip(state: state),
        ],
      ),
    );
  }

  Widget _buildBody(BuildContext context, ConsoleState state) {
    switch (state.currentView) {
      case 'detail':
        return _ChannelDetail(state: state);
      case 'vca':
        return const VcaScreen();
      case 'geq':
        return const GeqScreen();
      default:
        return _FaderBank(state: state);
    }
  }
}

class _OverviewBar extends StatelessWidget {
  final ConsoleState state;
  const _OverviewBar({required this.state});

  @override
  Widget build(BuildContext context) {
    final model = state.model!;
    return Container(
      height: 48,
      color: const Color(0xFF12121F),
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Row(
        children: [
          _NavChip(
            label: 'Inputs',
            selected: state.currentView == 'mix' || state.currentView == 'detail',
            onTap: () => state.setView('mix'),
          ),
          const SizedBox(width: 8),
          _NavChip(
            label: 'VCAs / POP',
            selected: state.currentView == 'vca',
            onTap: () => state.setView('vca'),
          ),
          const SizedBox(width: 8),
          _NavChip(
            label: 'GEQ',
            selected: state.currentView == 'geq',
            onTap: () => state.setView('geq'),
          ),
          const SizedBox(width: 8),
          _NavChip(
            label: 'Scenes',
            selected: false,
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const ScenesScreen()),
              );
            },
          ),
          const SizedBox(width: 8),
          _NavChip(
            label: 'Locks',
            selected: false,
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const SafetyScreen()),
              );
            },
          ),
          const Spacer(),
          Text(
            '${model.primaryInputs} in · ${model.mixBuses} bus · ${model.vcas} VCA',
            style: const TextStyle(fontSize: 11, color: Colors.white38),
          ),
        ],
      ),
    );
  }
}

class _NavChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _NavChip({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFE94560).withOpacity(0.25) : Colors.white10,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: selected ? const Color(0xFFE94560) : Colors.transparent),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 12,
            fontWeight: selected ? FontWeight.w600 : FontWeight.normal,
            color: selected ? Colors.white : Colors.white60,
          ),
        ),
      ),
    );
  }
}

class _BankSelector extends StatelessWidget {
  final ConsoleState state;
  const _BankSelector({required this.state});

  @override
  Widget build(BuildContext context) {
    if (state.currentView != 'mix' && state.currentView != 'detail') {
      return const SizedBox.shrink();
    }
    final totalBanks = (state.inputs.length / 8).ceil();
    return Container(
      height: 40,
      color: const Color(0xFF0A0A12),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        itemCount: totalBanks,
        itemBuilder: (context, i) {
          final selected = state.selectedBank == i;
          final start = i * 8 + 1;
          final end = ((i + 1) * 8).clamp(0, state.inputs.length);
          return Padding(
            padding: const EdgeInsets.only(right: 6),
            child: GestureDetector(
              onTap: () => state.setBank(i),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: selected ? const Color(0xFFE94560) : Colors.white.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  '$start–$end',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: selected ? Colors.white : Colors.white54,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _FaderBank extends StatelessWidget {
  final ConsoleState state;
  const _FaderBank({required this.state});

  @override
  Widget build(BuildContext context) {
    final start = state.selectedBank * 8;
    final end = (start + 8).clamp(0, state.inputs.length);
    final visible = state.inputs.sublist(start, end);

    return ListView.builder(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
      itemCount: visible.length,
      itemBuilder: (context, i) {
        final ch = visible[i];
        final idx = start + i;
        return ChannelStrip(
          index: idx,
          name: ch.name,
          fader: ch.fader,
          mute: ch.mute,
          solo: ch.solo,
          meter: ch.meter,
          isSelected: state.selectedInput == idx,
          colorIndex: ch.colorIndex,
          locked: ch.locked,
          onFaderChanged: (v) => state.setInputFader(idx, v),
          onMute: () => state.toggleInputMute(idx),
          onSolo: () => state.toggleInputSolo(idx),
          onSelect: () => state.selectChannel(idx),
        );
      },
    );
  }
}

class _MastersStrip extends StatelessWidget {
  final ConsoleState state;
  const _MastersStrip({required this.state});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 150,
      color: const Color(0xFF12121F),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          for (int i = 0; i < state.masters.length; i++)
            ChannelStrip(
              index: i,
              name: state.masters[i].name,
              fader: state.masters[i].fader,
              mute: false,
              solo: false,
              meter: state.masters[i].meter,
              isSelected: false,
              isMaster: true,
              onFaderChanged: (v) => state.setMasterFader(i, v),
              onMute: () {},
              onSolo: () {},
              onSelect: () {},
            ),
        ],
      ),
    );
  }
}

class _ChannelDetail extends StatelessWidget {
  final ConsoleState state;
  const _ChannelDetail({required this.state});

  @override
  Widget build(BuildContext context) {
    final ch = state.inputs[state.selectedInput];
    return Container(
      color: const Color(0xFF0F0F1A),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 8, 16, 0),
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.arrow_back),
                  onPressed: () => state.setView('mix'),
                ),
                Text(ch.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const Spacer(),
                FilledButton.tonal(
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => EqScreen(channelIndex: state.selectedInput),
                      ),
                    );
                  },
                  child: const Text('Full EQ Editor'),
                ),
                const SizedBox(width: 8),
                IconButton(
                  icon: const Icon(Icons.edit, size: 20),
                  tooltip: 'Rename channel',
                  onPressed: () async {
                    final ctrl = TextEditingController(text: ch.name);
                    final name = await showDialog<String>(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        backgroundColor: const Color(0xFF1A1A2E),
                        title: const Text('Channel Name'),
                        content: TextField(controller: ctrl, autofocus: true),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
                          FilledButton(
                            onPressed: () => Navigator.pop(ctx, ctrl.text),
                            child: const Text('Save'),
                          ),
                        ],
                      ),
                    );
                    if (name != null) state.setChannelName(state.selectedInput, name);
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.palette, size: 20),
                  tooltip: 'Channel colour',
                  onPressed: () {
                    showModalBottomSheet(
                      context: context,
                      backgroundColor: const Color(0xFF1A1A2E),
                      builder: (ctx) => Padding(
                        padding: const EdgeInsets.all(16),
                        child: Wrap(
                          spacing: 12,
                          children: List.generate(channelColorPalette.length, (i) {
                            return GestureDetector(
                              onTap: () {
                                state.setChannelColor(state.selectedInput, i);
                                Navigator.pop(ctx);
                              },
                              child: Container(
                                width: 36,
                                height: 36,
                                decoration: BoxDecoration(
                                  color: Color(channelColorPalette[i]),
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: ch.colorIndex == i ? Colors.white : Colors.transparent,
                                    width: 2,
                                  ),
                                ),
                              ),
                            );
                          }),
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
          Expanded(
            child: Row(
              children: [
                Expanded(
                  child: _DetailColumn(
                    title: 'Input',
                    children: [
                      _Knob('Gain', '0.0 dB'),
                      _Knob('Pan', 'C'),
                      _Knob('Delay', '0.0 ms'),
                    ],
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: _DetailColumn(
                    title: 'EQ Preview',
                    children: [
                      Container(
                        height: 140,
                        margin: const EdgeInsets.only(top: 8),
                        decoration: BoxDecoration(
                          color: Colors.black26,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.white12),
                        ),
                        child: const Center(
                          child: Text(
                            'Tap “Full EQ Editor” for\n4-band parametric control',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.white30),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: _DetailColumn(
                    title: 'Dynamics',
                    children: [
                      _Knob('Comp', '–'),
                      _Knob('Gate', '–'),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _DetailColumn extends StatelessWidget {
  final String title;
  final List<Widget> children;
  const _DetailColumn({required this.title, required this.children});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w600, color: Colors.white70)),
          ...children,
        ],
      ),
    );
  }
}

class _Knob extends StatelessWidget {
  final String label;
  final String value;
  const _Knob(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Column(
        children: [
          Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white10,
              border: Border.all(color: Colors.white24),
            ),
            child: Center(child: Text(value, style: const TextStyle(fontSize: 11, color: Colors.white70))),
          ),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(fontSize: 11, color: Colors.white54)),
        ],
      ),
    );
  }
}
