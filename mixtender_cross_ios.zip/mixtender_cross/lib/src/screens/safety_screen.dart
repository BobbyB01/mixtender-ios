import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/console_state.dart';

/// Safety locks – original Mixtender 2 feature that restricts mix access.
class SafetyScreen extends StatelessWidget {
  const SafetyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<ConsoleState>();
    final model = state.model!;

    return Scaffold(
      appBar: AppBar(title: const Text('Safety Locks')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SwitchListTile(
            title: const Text('Enable Safety Locks'),
            subtitle: const Text(
              'When enabled, locked buses cannot be changed from this device. '
              'Useful when sharing iPads with performers.',
            ),
            value: state.safetyLocksEnabled,
            activeColor: const Color(0xFFE94560),
            onChanged: (v) => state.setSafetyLocks(v),
          ),
          const Divider(height: 32),
          const Text(
            'Lock individual buses / mixes',
            style: TextStyle(fontWeight: FontWeight.w600, color: Colors.white70),
          ),
          const SizedBox(height: 8),
          const Text(
            'Locked items show a lock icon and ignore fader / mute changes.',
            style: TextStyle(fontSize: 12, color: Colors.white38),
          ),
          const SizedBox(height: 16),
          ...List.generate(model.auxBuses.clamp(0, 24), (i) {
            final locked = state.isBusLocked(i);
            return CheckboxListTile(
              title: Text('AUX ${i + 1}'),
              value: locked,
              activeColor: const Color(0xFFE94560),
              onChanged: state.safetyLocksEnabled
                  ? (_) => state.toggleBusLock(i)
                  : null,
              secondary: Icon(
                locked ? Icons.lock : Icons.lock_open,
                color: locked ? const Color(0xFFE94560) : Colors.white24,
              ),
            );
          }),
        ],
      ),
    );
  }
}
