import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/console_state.dart';

/// Klark Teknik DN370-style graphic EQ control (original Mixtender 2 feature).
class GeqScreen extends StatefulWidget {
  const GeqScreen({super.key});

  @override
  State<GeqScreen> createState() => _GeqScreenState();
}

class _GeqScreenState extends State<GeqScreen> {
  // 31-band GEQ (classic DN370)
  late List<double> bands; // 0.0–1.0, 0.5 = flat
  int selectedGeq = 0;

  static const List<String> freqLabels = [
    '20', '25', '31.5', '40', '50', '63', '80', '100', '125', '160',
    '200', '250', '315', '400', '500', '630', '800', '1k', '1k25', '1k6',
    '2k', '2k5', '3k15', '4k', '5k', '6k3', '8k', '10k', '12k5', '16k', '20k',
  ];

  @override
  void initState() {
    super.initState();
    bands = List.filled(31, 0.5);
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<ConsoleState>();
    final maxGeq = state.model?.geqs ?? 8;

    return Column(
      children: [
        // GEQ selector
        Container(
          height: 44,
          color: const Color(0xFF0A0A12),
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
            itemCount: maxGeq.clamp(1, 12),
            itemBuilder: (context, i) {
              final selected = selectedGeq == i;
              return Padding(
                padding: const EdgeInsets.only(right: 6),
                child: GestureDetector(
                  onTap: () => setState(() => selectedGeq = i),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: selected ? const Color(0xFFE94560) : Colors.white.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      'GEQ ${i + 1}',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: selected ? Colors.white : Colors.white54,
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),

        // Flat / Reset
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          child: Row(
            children: [
              const Text('31-band Graphic EQ (DN370 style)',
                  style: TextStyle(color: Colors.white54, fontSize: 12)),
              const Spacer(),
              TextButton(
                onPressed: () => setState(() => bands = List.filled(31, 0.5)),
                child: const Text('Flat'),
              ),
            ],
          ),
        ),

        // Vertical faders for each band
        Expanded(
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 4),
            itemCount: 31,
            itemBuilder: (context, i) {
              return SizedBox(
                width: 36,
                child: Column(
                  children: [
                    Expanded(
                      child: RotatedBox(
                        quarterTurns: 3,
                        child: SliderTheme(
                          data: SliderTheme.of(context).copyWith(
                            trackHeight: 4,
                            thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 7),
                            activeTrackColor: const Color(0xFFE94560),
                            inactiveTrackColor: Colors.white24,
                            thumbColor: Colors.white,
                          ),
                          child: Slider(
                            value: bands[i],
                            onChanged: (v) => setState(() => bands[i] = v),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      freqLabels[i],
                      style: const TextStyle(fontSize: 9, color: Colors.white38),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 8),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
