import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/console_state.dart';

/// Full-screen parametric EQ editor – mirrors the original Mixtender 2 feature.
class EqScreen extends StatefulWidget {
  final int channelIndex;
  const EqScreen({super.key, required this.channelIndex});

  @override
  State<EqScreen> createState() => _EqScreenState();
}

class _EqBand {
  double freq; // 0–1 mapped later
  double gain; // -15 … +15 dB approx as 0–1
  double q;
  bool enabled;
  _EqBand({this.freq = 0.5, this.gain = 0.5, this.q = 0.5, this.enabled = true});
}

class _EqScreenState extends State<EqScreen> {
  late List<_EqBand> bands;
  int selectedBand = 1; // 0=LF … 3=HF

  @override
  void initState() {
    super.initState();
    // Typical 4-band starting points
    bands = [
      _EqBand(freq: 0.15, gain: 0.5, q: 0.4), // LF
      _EqBand(freq: 0.35, gain: 0.5, q: 0.5), // LMF
      _EqBand(freq: 0.6, gain: 0.5, q: 0.5),  // HMF
      _EqBand(freq: 0.85, gain: 0.5, q: 0.4), // HF
    ];
  }

  String _freqLabel(double v) {
    final hz = 20 * (20000 / 20).pow(v); // log scale approx
    if (hz < 1000) return '${hz.round()} Hz';
    return '${(hz / 1000).toStringAsFixed(1)} kHz';
  }

  String _gainLabel(double v) {
    final db = (v - 0.5) * 30; // –15 … +15
    return '${db >= 0 ? '+' : ''}${db.toStringAsFixed(1)} dB';
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<ConsoleState>();
    final name = state.inputs[widget.channelIndex].name;

    return Scaffold(
      appBar: AppBar(
        title: Text('EQ – $name'),
        actions: [
          TextButton(
            onPressed: () {
              setState(() {
                for (final b in bands) {
                  b.gain = 0.5;
                }
              });
            },
            child: const Text('Flat'),
          ),
        ],
      ),
      body: Column(
        children: [
          // Visual EQ curve placeholder
          Expanded(
            flex: 3,
            child: Container(
              margin: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFF0A0A12),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.white12),
              ),
              child: CustomPaint(
                painter: _EqCurvePainter(bands),
                child: const Center(
                  child: Text(
                    'Parametric EQ Curve',
                    style: TextStyle(color: Colors.white24, fontSize: 13),
                  ),
                ),
              ),
            ),
          ),

          // Band selector
          SizedBox(
            height: 48,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: List.generate(4, (i) {
                final labels = ['LF', 'LMF', 'HMF', 'HF'];
                final selected = selectedBand == i;
                return GestureDetector(
                  onTap: () => setState(() => selectedBand = i),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                    decoration: BoxDecoration(
                      color: selected ? const Color(0xFFE94560) : Colors.white10,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      labels[i],
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        color: selected ? Colors.white : Colors.white60,
                      ),
                    ),
                  ),
                );
              }),
            ),
          ),

          // Controls for selected band
          Expanded(
            flex: 2,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
              child: Column(
                children: [
                  _SliderRow(
                    label: 'Frequency',
                    valueLabel: _freqLabel(bands[selectedBand].freq),
                    value: bands[selectedBand].freq,
                    onChanged: (v) => setState(() => bands[selectedBand].freq = v),
                  ),
                  _SliderRow(
                    label: 'Gain',
                    valueLabel: _gainLabel(bands[selectedBand].gain),
                    value: bands[selectedBand].gain,
                    onChanged: (v) => setState(() => bands[selectedBand].gain = v),
                  ),
                  _SliderRow(
                    label: 'Q / Width',
                    valueLabel: bands[selectedBand].q.toStringAsFixed(2),
                    value: bands[selectedBand].q,
                    onChanged: (v) => setState(() => bands[selectedBand].q = v),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SliderRow extends StatelessWidget {
  final String label;
  final String valueLabel;
  final double value;
  final ValueChanged<double> onChanged;
  const _SliderRow({
    required this.label,
    required this.valueLabel,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(width: 90, child: Text(label, style: const TextStyle(color: Colors.white70))),
        Expanded(
          child: Slider(
            value: value,
            onChanged: onChanged,
            activeColor: const Color(0xFFE94560),
          ),
        ),
        SizedBox(
          width: 80,
          child: Text(valueLabel, textAlign: TextAlign.right, style: const TextStyle(fontSize: 13)),
        ),
      ],
    );
  }
}

class _EqCurvePainter extends CustomPainter {
  final List<_EqBand> bands;
  _EqCurvePainter(this.bands);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFFE94560)
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke;

    final path = Path();
    // Simple visualisation of the four bands
    for (int i = 0; i < size.width.toInt(); i += 4) {
      final x = i.toDouble();
      final t = x / size.width;
      double y = size.height * 0.5;
      for (final b in bands) {
        final dist = (t - b.freq).abs();
        final influence = (1 - (dist / (0.15 + b.q * 0.3)).clamp(0.0, 1.0));
        y -= (b.gain - 0.5) * influence * size.height * 0.4;
      }
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    canvas.drawPath(path, paint);

    // Centre line
    final mid = Paint()
      ..color = Colors.white12
      ..strokeWidth = 1;
    canvas.drawLine(Offset(0, size.height / 2), Offset(size.width, size.height / 2), mid);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

extension on num {
  double pow(num exponent) => this.toDouble() * (1 + (exponent - 1) * 0.5); // cheap approx
}
