import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/console_state.dart';

class ScenesScreen extends StatefulWidget {
  const ScenesScreen({super.key});

  @override
  State<ScenesScreen> createState() => _ScenesScreenState();
}

class _ScenesScreenState extends State<ScenesScreen> {
  final _nameController = TextEditingController();

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<ConsoleState>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Scenes'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            tooltip: 'Save current as scene',
            onPressed: () => _showSaveDialog(context, state),
          ),
        ],
      ),
      body: state.scenes.isEmpty
          ? const Center(
              child: Text('No scenes saved yet.\nTap + to store the current mix.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white38)),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: state.scenes.length,
              itemBuilder: (context, i) {
                final s = state.scenes[i];
                final isCurrent = state.currentSceneIndex == i;
                return Card(
                  color: isCurrent
                      ? const Color(0xFFE94560).withOpacity(0.15)
                      : const Color(0xFF1A1A2E),
                  margin: const EdgeInsets.only(bottom: 8),
                  child: ListTile(
                    leading: Icon(
                      isCurrent ? Icons.play_circle_filled : Icons.play_circle_outline,
                      color: isCurrent ? const Color(0xFFE94560) : Colors.white54,
                    ),
                    title: Text(s.name,
                        style: TextStyle(
                          fontWeight: isCurrent ? FontWeight.bold : FontWeight.normal,
                        )),
                    subtitle: Text(
                      '${s.savedAt.hour.toString().padLeft(2, '0')}:'
                      '${s.savedAt.minute.toString().padLeft(2, '0')}  ·  '
                      '${s.inputFaders.length} channels',
                      style: const TextStyle(fontSize: 12, color: Colors.white38),
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline, size: 20),
                      onPressed: () => state.deleteScene(i),
                    ),
                    onTap: () {
                      state.recallScene(i);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Recalled “${s.name}”'),
                          duration: const Duration(seconds: 1),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
    );
  }

  void _showSaveDialog(BuildContext context, ConsoleState state) {
    _nameController.text = 'Scene ${state.scenes.length + 1}';
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A2E),
        title: const Text('Save Scene'),
        content: TextField(
          controller: _nameController,
          autofocus: true,
          decoration: const InputDecoration(
            labelText: 'Scene name',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
            onPressed: () {
              final name = _nameController.text.trim();
              if (name.isNotEmpty) {
                state.saveScene(name);
                Navigator.pop(ctx);
              }
            },
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFFE94560)),
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }
}
