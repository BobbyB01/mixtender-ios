import 'dart:async';
import 'dart:math';
import 'package:flutter/foundation.dart';
import '../models/console_model.dart';
import 'osc_service.dart';

/// Channel colour palette matching typical Midas / Mixtender colour coding.
const List<int> channelColorPalette = [
  0xFFE94560, // red
  0xFFFF9800, // orange
  0xFFFFEB3B, // yellow
  0xFF4CAF50, // green
  0xFF2196F3, // blue
  0xFF9C27B0, // purple
  0xFF00BCD4, // cyan
  0xFFFFFFFF, // white
];

class ChannelState {
  double fader = 0.75;
  bool mute = false;
  bool solo = false;
  String name;
  double meter = 0.0;
  int colorIndex = 0;
  bool locked = false; // safety lock – original Mixtender feature

  ChannelState(this.name);
}

class VcaGroup {
  final String name;
  double fader = 0.75;
  bool mute = false;
  bool solo = false;
  double meter = 0.0;
  final List<int> members; // indices into inputs

  VcaGroup(this.name, this.members);
}

class Scene {
  final String name;
  final DateTime savedAt;
  final Map<int, double> inputFaders;
  final Map<int, bool> inputMutes;
  final Map<int, String> inputNames;
  final Map<int, int> inputColors;

  Scene({
    required this.name,
    required this.savedAt,
    required this.inputFaders,
    required this.inputMutes,
    required this.inputNames,
    required this.inputColors,
  });
}

/// Full console state – mirrors original Mixtender 2 capabilities.
class ConsoleState extends ChangeNotifier {
  final OscService osc;
  StreamSubscription? _sub;
  Timer? _meterTimer;

  ConsoleModel? _model;
  ConsoleModel? get model => _model;

  late List<ChannelState> inputs;
  late List<ChannelState> auxReturns;
  late List<ChannelState> auxBuses;
  late List<ChannelState> matrices;
  late List<VcaGroup> vcas;
  late List<VcaGroup> popGroups;
  late List<ChannelState> masters;

  // Safety locks (original feature – restrict access to certain mixes)
  bool safetyLocksEnabled = false;
  final Set<int> lockedBuses = {}; // bus indices that are locked

  // Scenes
  final List<Scene> scenes = [];
  int? currentSceneIndex;

  int selectedInput = 0;
  int selectedBank = 0;
  int selectedVca = -1; // for member editing
  bool isFlipMode = false;
  bool isVcaFlip = false;
  String currentView = 'mix';

  ConsoleState(this.osc) {
    selectConsole(ConsoleModel.byType(ConsoleType.pro2));
    _sub = osc.messages.listen(_onOscMessage);
  }

  void selectConsole(ConsoleModel m) {
    _model = m;
    inputs = List.generate(m.primaryInputs, (i) => ChannelState('IN ${i + 1}'));
    auxReturns = List.generate(m.auxReturns, (i) => ChannelState('RTN ${i + 1}'));
    auxBuses = List.generate(m.auxBuses, (i) => ChannelState('AUX ${i + 1}'));
    matrices = List.generate(m.matrixBuses, (i) => ChannelState('MTX ${i + 1}'));
    vcas = List.generate(
      m.vcas,
      (i) => VcaGroup('VCA ${i + 1}', []),
    );
    popGroups = List.generate(
      m.popGroups,
      (i) => VcaGroup('POP ${i + 1}', []),
    );
    masters = [ChannelState('L'), ChannelState('R'), ChannelState('M')];
    selectedInput = 0;
    selectedBank = 0;
    selectedVca = -1;
    lockedBuses.clear();
    scenes.clear();
    currentSceneIndex = null;
    notifyListeners();
  }

  void enterDemo(ConsoleModel m) {
    selectConsole(m);
    osc.enterDemoMode();
    _seedDemoData();
    _startDemoMeters();
  }

  void _seedDemoData() {
    final names = [
      'Kick', 'Snare', 'HiHat', 'Tom1', 'Tom2', 'OH L', 'OH R', 'Bass',
      'Gtr L', 'Gtr R', 'Keys L', 'Keys R', 'Vocal 1', 'Vocal 2', 'Vocal 3', 'Choir',
    ];
    for (var i = 0; i < inputs.length; i++) {
      inputs[i].fader = 0.55 + (i % 6) * 0.06;
      inputs[i].meter = 0.2 + (i % 8) * 0.08;
      inputs[i].colorIndex = i % 8;
      if (i < names.length) inputs[i].name = names[i];
      if (i % 13 == 0) inputs[i].mute = true;
      if (i % 17 == 0) inputs[i].solo = true;
    }
    // Seed some VCA memberships
    if (vcas.isNotEmpty) {
      vcas[0].members.addAll([0, 1, 2, 3, 4]); // drums
      vcas[0].name = 'Drums';
    }
    if (vcas.length > 1) {
      vcas[1].members.addAll([8, 9, 10, 11]);
      vcas[1].name = 'Band';
    }
    if (vcas.length > 2) {
      vcas[2].members.addAll([12, 13, 14, 15]);
      vcas[2].name = 'Vocals';
    }
    for (var i = 0; i < masters.length; i++) {
      masters[i].fader = 0.7;
      masters[i].meter = 0.4;
    }
    // Seed a couple of scenes
    saveScene('Default');
    saveScene('Verse');
    notifyListeners();
  }

  // ---------------------------------------------------------------------------
  // Live meters (demo simulation + real OSC subscription)
  // ---------------------------------------------------------------------------

  void _startDemoMeters() {
    _meterTimer?.cancel();
    if (!osc.isDemoMode) return;
    final rng = Random();
    _meterTimer = Timer.periodic(const Duration(milliseconds: 80), (_) {
      for (final ch in inputs) {
        // Smooth random walk
        ch.meter = (ch.meter + (rng.nextDouble() - 0.48) * 0.12).clamp(0.0, 1.0);
        if (ch.mute) ch.meter *= 0.15;
      }
      for (final m in masters) {
        m.meter = (m.meter + (rng.nextDouble() - 0.48) * 0.08).clamp(0.0, 1.0);
      }
      notifyListeners();
    });
  }

  void startMeterSubscription() {
    // Request meter data from console (protocol varies; this is the common pattern)
    if (osc.isConnected) {
      for (var i = 0; i < inputs.length && i < 64; i++) {
        osc.sendRaw('/enPPCMeterMessage/enVirtualMicInputs/enMeter/$i', []);
      }
    }
  }

  // ---------------------------------------------------------------------------
  // Safety locks (original Mixtender feature)
  // ---------------------------------------------------------------------------

  void setSafetyLocks(bool enabled) {
    safetyLocksEnabled = enabled;
    notifyListeners();
  }

  void toggleBusLock(int busIndex) {
    if (lockedBuses.contains(busIndex)) {
      lockedBuses.remove(busIndex);
    } else {
      lockedBuses.add(busIndex);
    }
    notifyListeners();
  }

  bool isBusLocked(int busIndex) =>
      safetyLocksEnabled && lockedBuses.contains(busIndex);

  // ---------------------------------------------------------------------------
  // Channel naming & colour
  // ---------------------------------------------------------------------------

  void setChannelName(int index, String name) {
    if (index < 0 || index >= inputs.length) return;
    inputs[index].name = name.trim().isEmpty ? 'IN ${index + 1}' : name.trim();
    // OSC string message for name (community endpoint)
    osc.sendRaw(
      '/enPPCStringMessage/enVirtualMicInputs/enPathnamePrefix/$index',
      [inputs[index].name],
    );
    notifyListeners();
  }

  void setChannelColor(int index, int colorIndex) {
    if (index < 0 || index >= inputs.length) return;
    inputs[index].colorIndex = colorIndex.clamp(0, channelColorPalette.length - 1);
    notifyListeners();
  }

  // ---------------------------------------------------------------------------
  // VCA / POP member editing
  // ---------------------------------------------------------------------------

  void setSelectedVca(int index) {
    selectedVca = index;
    notifyListeners();
  }

  void toggleVcaMember(int vcaIndex, int channelIndex) {
    if (vcaIndex < 0 || vcaIndex >= vcas.length) return;
    final g = vcas[vcaIndex];
    if (g.members.contains(channelIndex)) {
      g.members.remove(channelIndex);
    } else {
      g.members.add(channelIndex);
    }
    notifyListeners();
  }

  void togglePopMember(int popIndex, int channelIndex) {
    if (popIndex < 0 || popIndex >= popGroups.length) return;
    final g = popGroups[popIndex];
    if (g.members.contains(channelIndex)) {
      g.members.remove(channelIndex);
    } else {
      g.members.add(channelIndex);
    }
    notifyListeners();
  }

  // ---------------------------------------------------------------------------
  // Scenes
  // ---------------------------------------------------------------------------

  void saveScene(String name) {
    final faders = <int, double>{};
    final mutes = <int, bool>{};
    final names = <int, String>{};
    final colors = <int, int>{};
    for (var i = 0; i < inputs.length; i++) {
      faders[i] = inputs[i].fader;
      mutes[i] = inputs[i].mute;
      names[i] = inputs[i].name;
      colors[i] = inputs[i].colorIndex;
    }
    scenes.add(Scene(
      name: name,
      savedAt: DateTime.now(),
      inputFaders: faders,
      inputMutes: mutes,
      inputNames: names,
      inputColors: colors,
    ));
    currentSceneIndex = scenes.length - 1;
    notifyListeners();
  }

  void recallScene(int index) {
    if (index < 0 || index >= scenes.length) return;
    final s = scenes[index];
    for (final e in s.inputFaders.entries) {
      if (e.key < inputs.length) {
        inputs[e.key].fader = e.value;
        osc.setFader(e.key, e.value);
      }
    }
    for (final e in s.inputMutes.entries) {
      if (e.key < inputs.length) {
        inputs[e.key].mute = e.value;
        osc.setMute(e.key, e.value);
      }
    }
    for (final e in s.inputNames.entries) {
      if (e.key < inputs.length) inputs[e.key].name = e.value;
    }
    for (final e in s.inputColors.entries) {
      if (e.key < inputs.length) inputs[e.key].colorIndex = e.value;
    }
    currentSceneIndex = index;
    notifyListeners();
  }

  void deleteScene(int index) {
    if (index < 0 || index >= scenes.length) return;
    scenes.removeAt(index);
    if (currentSceneIndex == index) currentSceneIndex = null;
    else if (currentSceneIndex != null && currentSceneIndex! > index) {
      currentSceneIndex = currentSceneIndex! - 1;
    }
    notifyListeners();
  }

  // ---------------------------------------------------------------------------
  // Basic channel actions
  // ---------------------------------------------------------------------------

  void setInputFader(int index, double value) {
    if (index < 0 || index >= inputs.length) return;
    if (inputs[index].locked) return;
    inputs[index].fader = value.clamp(0.0, 1.0);
    osc.setFader(index, inputs[index].fader);
    notifyListeners();
  }

  void toggleInputMute(int index) {
    if (index < 0 || index >= inputs.length) return;
    if (inputs[index].locked) return;
    inputs[index].mute = !inputs[index].mute;
    osc.setMute(index, inputs[index].mute);
    notifyListeners();
  }

  void toggleInputSolo(int index) {
    if (index < 0 || index >= inputs.length) return;
    if (inputs[index].locked) return;
    inputs[index].solo = !inputs[index].solo;
    osc.setSolo(index, inputs[index].solo);
    notifyListeners();
  }

  void setMasterFader(int index, double value) {
    if (index < 0 || index >= masters.length) return;
    masters[index].fader = value.clamp(0.0, 1.0);
    osc.setMasterFader(index + 1, masters[index].fader);
    notifyListeners();
  }

  void selectChannel(int index) {
    selectedInput = index;
    currentView = 'detail';
    notifyListeners();
  }

  void setBank(int bank) {
    selectedBank = bank;
    notifyListeners();
  }

  void toggleFlipMode() {
    isFlipMode = !isFlipMode;
    notifyListeners();
  }

  void setView(String view) {
    currentView = view;
    notifyListeners();
  }

  void refresh() => notifyListeners();

  // ---------------------------------------------------------------------------
  // Incoming OSC
  // ---------------------------------------------------------------------------

  void _onOscMessage(OscMessage msg) {
    final parts = msg.address.split('/');
    if (parts.length < 5) return;

    final group = parts[2];
    final param = parts[3];
    final index = int.tryParse(parts.length > 4 ? parts[4] : '');

    if (group == 'enVirtualMicInputs' && index != null && index < inputs.length) {
      if (param == 'enFaderLevel' && msg.arguments.isNotEmpty) {
        final v = msg.arguments.first;
        if (v is num) {
          inputs[index].fader = v.toDouble();
          notifyListeners();
        }
      } else if (param == 'enMuteStatus' && msg.arguments.isNotEmpty) {
        final v = msg.arguments.first;
        if (v is int) {
          inputs[index].mute = v != 0;
          notifyListeners();
        }
      } else if (param == 'enMeter' && msg.arguments.isNotEmpty) {
        final v = msg.arguments.first;
        if (v is num) {
          inputs[index].meter = v.toDouble();
          notifyListeners();
        }
      }
    }
  }

  @override
  void dispose() {
    _sub?.cancel();
    _meterTimer?.cancel();
    super.dispose();
  }
}
