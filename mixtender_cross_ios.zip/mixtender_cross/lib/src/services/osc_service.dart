import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import '../utils/simple_osc.dart';

/// Handles OSC communication with a Midas PRO Series console.
/// Protocol details based on community reverse-engineering of the
/// Remote Control Server used by the official Mixtender 2 iPad app.
class OscService extends ChangeNotifier {
  static const int defaultPort = 10002; // Confirmed by Midas support

  RawDatagramSocket? _socket;
  InternetAddress? _consoleAddress;
  int _consolePort = defaultPort;

  bool _isConnected = false;
  bool _isDemoMode = false;
  String? _lastError;

  // Incoming message stream
  final _messageController = StreamController<OscMessage>.broadcast();
  Stream<OscMessage> get messages => _messageController.stream;

  bool get isConnected => _isConnected;
  bool get isDemoMode => _isDemoMode;
  String? get lastError => _lastError;
  String? get connectedIp => _consoleAddress?.address;

  /// Connect to a real console.
  Future<bool> connect(String ip, {int port = defaultPort}) async {
    await disconnect();
    _lastError = null;

    try {
      final address = InternetAddress(ip);
      _socket = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
      _consoleAddress = address;
      _consolePort = port;

      _socket!.listen((event) {
        if (event == RawSocketEvent.read) {
          final datagram = _socket!.receive();
          if (datagram != null) {
            final msg = OscMessage.fromBytes(Uint8List.fromList(datagram.data));
            if (msg != null) {
              _messageController.add(msg);
            }
          }
        }
      });

      // Simple connectivity probe – request mute status of input 1
      final probe = OscMessage(
        '/enPPCSwitchMessage/enVirtualMicInputs/enMuteStatus/0',
      );
      _sendRaw(probe);

      _isConnected = true;
      _isDemoMode = false;
      notifyListeners();
      return true;
    } catch (e) {
      _lastError = e.toString();
      _isConnected = false;
      notifyListeners();
      return false;
    }
  }

  /// Enter offline demo mode (no network required).
  void enterDemoMode() {
    disconnect();
    _isDemoMode = true;
    _isConnected = false;
    notifyListeners();
  }

  Future<void> disconnect() async {
    _socket?.close();
    _socket = null;
    _consoleAddress = null;
    _isConnected = false;
    _isDemoMode = false;
    notifyListeners();
  }

  // ---------------------------------------------------------------------------
  // High-level helpers matching the reverse-engineered protocol
  // ---------------------------------------------------------------------------

  /// Set fader level (0.0 – 1.0). Channel is 0-indexed.
  void setFader(int channel, double value) {
    final clamped = value.clamp(0.0000001, 0.9999999);
    _send('/enPPCFaderMessage/enVirtualMicInputs/enFaderLevel/$channel',
        [clamped]);
  }

  /// Request current fader value.
  void getFader(int channel) {
    _send('/enPPCFaderMessage/enVirtualMicInputs/enFaderLevel/$channel', []);
  }

  /// Toggle or set mute. Most switches are toggles when sent with 1.
  void setMute(int channel, bool muted) {
    _send('/enPPCSwitchMessage/enVirtualMicInputs/enMuteStatus/$channel',
        [muted ? 1 : 0]);
  }

  void getMute(int channel) {
    _send('/enPPCSwitchMessage/enVirtualMicInputs/enMuteStatus/$channel', []);
  }

  void setSolo(int channel, bool soloed) {
    _send('/enPPCSwitchMessage/enVirtualMicInputs/enSoloStatus/$channel',
        [soloed ? 1 : 0]);
  }

  /// Master faders (L=1, R=2, Mono=3 according to Midas docs)
  void setMasterFader(int masterIndex, double value) {
    final clamped = value.clamp(0.0000001, 0.9999999);
    _send('/enPPCFaderMessage/enVirtualMasters/enFaderLevel/$masterIndex',
        [clamped]);
  }

  /// Aux / Submix fader
  void setAuxFader(int auxIndex, double value) {
    final clamped = value.clamp(0.0000001, 0.9999999);
    _send('/enPPCFaderMessage/enVirtualSubMixes/enFaderLevel/$auxIndex',
        [clamped]);
  }

  /// Generic send for advanced use
  void sendRaw(String address, List<Object> args) {
    _send(address, args);
  }

  // ---------------------------------------------------------------------------
  // Internal
  // ---------------------------------------------------------------------------

  void _send(String address, List<Object> args) {
    if (_isDemoMode) return; // silently ignore in demo
    if (!_isConnected || _socket == null || _consoleAddress == null) return;

    final msg = OscMessage(address, arguments: args);
    _sendRaw(msg);
  }

  void _sendRaw(OscMessage msg) {
    try {
      final bytes = msg.toBytes();
      _socket?.send(bytes, _consoleAddress!, _consolePort);
    } catch (e) {
      _lastError = 'Send failed: $e';
      notifyListeners();
    }
  }

  @override
  void dispose() {
    disconnect();
    _messageController.close();
    super.dispose();
  }
}
