/// Accurate channel / bus counts for every Midas PRO Series console
/// supported by the original Mixtender 2 app.
enum ConsoleType {
  pro1,
  pro2,
  pro2c,
  pro3,
  pro6,
  pro9,
  proX,
  xl8,
}

class ConsoleModel {
  final ConsoleType type;
  final String displayName;
  final int primaryInputs;
  final int auxReturns;
  final int maxMixChannels;
  final int mixBuses;
  final int auxBuses;
  final int matrixBuses;
  final int masters; // L + R + Mono
  final int vcas;
  final int popGroups;
  final int geqs;
  final String description;

  const ConsoleModel({
    required this.type,
    required this.displayName,
    required this.primaryInputs,
    required this.auxReturns,
    required this.maxMixChannels,
    required this.mixBuses,
    required this.auxBuses,
    required this.matrixBuses,
    this.masters = 3,
    required this.vcas,
    required this.popGroups,
    required this.geqs,
    required this.description,
  });

  static const List<ConsoleModel> all = [
    ConsoleModel(
      type: ConsoleType.pro1,
      displayName: 'PRO1',
      primaryInputs: 48,
      auxReturns: 8,
      maxMixChannels: 56,
      mixBuses: 27,
      auxBuses: 16,
      matrixBuses: 8,
      vcas: 8,
      popGroups: 6,
      geqs: 28,
      description: '48 input channels, 27 mix buses',
    ),
    ConsoleModel(
      type: ConsoleType.pro2,
      displayName: 'PRO2',
      primaryInputs: 56,
      auxReturns: 8,
      maxMixChannels: 64,
      mixBuses: 27,
      auxBuses: 16,
      matrixBuses: 8,
      vcas: 8,
      popGroups: 6,
      geqs: 28,
      description: '56 mic/line + 8 returns → 64 channels, 27 buses',
    ),
    ConsoleModel(
      type: ConsoleType.pro2c,
      displayName: 'PRO2C',
      primaryInputs: 56,
      auxReturns: 8,
      maxMixChannels: 64,
      mixBuses: 27,
      auxBuses: 16,
      matrixBuses: 8,
      vcas: 8,
      popGroups: 6,
      geqs: 28,
      description: 'Compact surface, same I/O as PRO2',
    ),
    ConsoleModel(
      type: ConsoleType.pro3,
      displayName: 'PRO3',
      primaryInputs: 48,
      auxReturns: 8,
      maxMixChannels: 72,
      mixBuses: 27,
      auxBuses: 16,
      matrixBuses: 8,
      vcas: 10,
      popGroups: 6,
      geqs: 28,
      description: '48 primary inputs, 27 mix buses',
    ),
    ConsoleModel(
      type: ConsoleType.pro6,
      displayName: 'PRO6',
      primaryInputs: 56,
      auxReturns: 8,
      maxMixChannels: 80,
      mixBuses: 35,
      auxBuses: 16,
      matrixBuses: 16,
      vcas: 10,
      popGroups: 6,
      geqs: 36,
      description: '56 primary inputs, 35 mix buses',
    ),
    ConsoleModel(
      type: ConsoleType.pro9,
      displayName: 'PRO9',
      primaryInputs: 80,
      auxReturns: 8,
      maxMixChannels: 104,
      mixBuses: 35,
      auxBuses: 16,
      matrixBuses: 16,
      vcas: 10,
      popGroups: 6,
      geqs: 36,
      description: '80 primary inputs, 35 mix buses',
    ),
    ConsoleModel(
      type: ConsoleType.proX,
      displayName: 'PRO X',
      primaryInputs: 144,
      auxReturns: 24,
      maxMixChannels: 168,
      mixBuses: 99,
      auxBuses: 72,
      matrixBuses: 24,
      vcas: 10,
      popGroups: 8,
      geqs: 36,
      description: '144 primary + 24 returns → 168 channels, 99 buses (Neutron)',
    ),
    ConsoleModel(
      type: ConsoleType.xl8,
      displayName: 'XL8',
      primaryInputs: 96,
      auxReturns: 16,
      maxMixChannels: 112,
      mixBuses: 51,
      auxBuses: 32,
      matrixBuses: 16,
      vcas: 12,
      popGroups: 8,
      geqs: 48,
      description: 'Flagship system – 96–112 inputs, 51 buses',
    ),
  ];

  static ConsoleModel byType(ConsoleType t) =>
      all.firstWhere((c) => c.type == t);
}
