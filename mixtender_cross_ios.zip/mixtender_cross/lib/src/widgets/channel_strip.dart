import 'package:flutter/material.dart';
import '../services/console_state.dart';

class ChannelStrip extends StatelessWidget {
  final int index;
  final String name;
  final double fader;
  final bool mute;
  final bool solo;
  final double meter;
  final bool isSelected;
  final bool isMaster;
  final int colorIndex;
  final bool locked;
  final ValueChanged<double> onFaderChanged;
  final VoidCallback onMute;
  final VoidCallback onSolo;
  final VoidCallback onSelect;

  const ChannelStrip({
    super.key,
    required this.index,
    required this.name,
    required this.fader,
    required this.mute,
    required this.solo,
    required this.meter,
    required this.isSelected,
    this.isMaster = false,
    this.colorIndex = 0,
    this.locked = false,
    required this.onFaderChanged,
    required this.onMute,
    required this.onSolo,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    final accent = Color(channelColorPalette[colorIndex.clamp(0, channelColorPalette.length - 1)]);

    return GestureDetector(
      onTap: onSelect,
      child: Container(
        width: 72,
        margin: const EdgeInsets.symmetric(horizontal: 4),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF2A2A45) : const Color(0xFF1A1A2E),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: isSelected ? const Color(0xFFE94560) : accent.withOpacity(0.4),
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Column(
          children: [
            // Colour bar + name
            Container(
              height: 4,
              decoration: BoxDecoration(
                color: accent,
                borderRadius: const BorderRadius.vertical(top: Radius.circular(7)),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 4, bottom: 2),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (locked)
                    const Icon(Icons.lock, size: 10, color: Colors.white38),
                  Flexible(
                    child: Text(
                      name,
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: isMaster ? const Color(0xFFE94560) : Colors.white,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),

            // Meter
            Expanded(
              flex: 1,
              child: Container(
                width: 8,
                margin: const EdgeInsets.symmetric(vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.black26,
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Align(
                  alignment: Alignment.bottomCenter,
                  child: FractionallySizedBox(
                    heightFactor: meter.clamp(0.0, 1.0),
                    child: Container(
                      decoration: BoxDecoration(
                        color: meter > 0.85
                            ? Colors.red
                            : meter > 0.7
                                ? Colors.orange
                                : Colors.greenAccent,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  ),
                ),
              ),
            ),

            // Fader
            Expanded(
              flex: 5,
              child: IgnorePointer(
                ignoring: locked,
                child: Opacity(
                  opacity: locked ? 0.4 : 1.0,
                  child: RotatedBox(
                    quarterTurns: 3,
                    child: SliderTheme(
                      data: SliderTheme.of(context).copyWith(
                        trackHeight: 6,
                        thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 10),
                        activeTrackColor: const Color(0xFFE94560),
                        inactiveTrackColor: Colors.white24,
                        thumbColor: Colors.white,
                      ),
                      child: Slider(
                        value: fader.clamp(0.0, 1.0),
                        onChanged: onFaderChanged,
                      ),
                    ),
                  ),
                ),
              ),
            ),

            // Mute / Solo
            if (!isMaster) ...[
              const SizedBox(height: 2),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _smallButton(
                    label: 'M',
                    active: mute,
                    activeColor: Colors.red,
                    onTap: locked ? () {} : onMute,
                  ),
                  const SizedBox(width: 4),
                  _smallButton(
                    label: 'S',
                    active: solo,
                    activeColor: Colors.yellow.shade700,
                    onTap: locked ? () {} : onSolo,
                  ),
                ],
              ),
            ],
            const SizedBox(height: 6),
          ],
        ),
      ),
    );
  }

  Widget _smallButton({
    required String label,
    required bool active,
    required Color activeColor,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 26,
        height: 26,
        decoration: BoxDecoration(
          color: active ? activeColor : Colors.white12,
          borderRadius: BorderRadius.circular(4),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.bold,
              color: active ? Colors.black : Colors.white70,
            ),
          ),
        ),
      ),
    );
  }
}
