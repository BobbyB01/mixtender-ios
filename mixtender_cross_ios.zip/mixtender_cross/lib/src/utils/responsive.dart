import 'package:flutter/material.dart';

/// Simple breakpoints for iPhone / iPad layout adaptation.
class Responsive {
  final BuildContext context;
  Responsive(this.context);

  Size get size => MediaQuery.sizeOf(context);
  double get width => size.width;
  double get height => size.height;
  bool get isTablet => width >= 600;
  bool get isLandscape => width > height;
  bool get isPhone => !isTablet;

  /// Recommended number of visible channel strips.
  int get channelColumns {
    if (isTablet && isLandscape) return 12;
    if (isTablet) return 8;
    if (isLandscape) return 8;
    return 4;
  }

  double get stripWidth {
    if (isTablet) return 80;
    return 72;
  }

  EdgeInsets get pagePadding {
    if (isTablet) return const EdgeInsets.symmetric(horizontal: 24, vertical: 12);
    return const EdgeInsets.symmetric(horizontal: 8, vertical: 8);
  }
}
