import 'dart:typed_data';
import 'dart:convert';

/// Minimal OSC 1.0 encoder / decoder sufficient for Midas PRO Series.
class OscMessage {
  final String address;
  final List<Object> arguments;

  OscMessage(this.address, {this.arguments = const []});

  /// Encode to OSC binary packet.
  Uint8List toBytes() {
    final builder = BytesBuilder();

    // Address
    builder.add(_padString(address));

    // Type tag string
    final typeTags = StringBuffer(',');
    for (final arg in arguments) {
      if (arg is int) {
        typeTags.write('i');
      } else if (arg is double || arg is num) {
        typeTags.write('f');
      } else if (arg is String) {
        typeTags.write('s');
      } else if (arg is bool) {
        typeTags.write(arg ? 'T' : 'F');
      }
    }
    builder.add(_padString(typeTags.toString()));

    // Arguments
    for (final arg in arguments) {
      if (arg is int) {
        builder.add(_int32(arg));
      } else if (arg is double || arg is num) {
        builder.add(_float32((arg as num).toDouble()));
      } else if (arg is String) {
        builder.add(_padString(arg));
      }
      // bools are encoded only in the type tag
    }

    return builder.toBytes();
  }

  /// Decode from OSC binary packet (very basic).
  static OscMessage? fromBytes(Uint8List data) {
    try {
      var offset = 0;

      String readString() {
        final end = data.indexOf(0, offset);
        if (end == -1) throw FormatException('Bad string');
        final s = utf8.decode(data.sublist(offset, end));
        offset = (end + 4) & ~3; // 4-byte align
        return s;
      }

      final address = readString();
      if (!address.startsWith('/')) return null;

      final typeTag = readString();
      if (!typeTag.startsWith(',')) return null;

      final args = <Object>[];
      for (var i = 1; i < typeTag.length; i++) {
        switch (typeTag[i]) {
          case 'i':
            final bd = ByteData.sublistView(data, offset, offset + 4);
            args.add(bd.getInt32(0, Endian.big));
            offset += 4;
            break;
          case 'f':
            final bd = ByteData.sublistView(data, offset, offset + 4);
            args.add(bd.getFloat32(0, Endian.big));
            offset += 4;
            break;
          case 's':
            args.add(readString());
            break;
          case 'T':
            args.add(true);
            break;
          case 'F':
            args.add(false);
            break;
        }
      }

      return OscMessage(address, arguments: args);
    } catch (_) {
      return null;
    }
  }

  static Uint8List _padString(String s) {
    final bytes = utf8.encode(s);
    final paddedLen = ((bytes.length + 1) + 3) & ~3;
    final result = Uint8List(paddedLen);
    result.setRange(0, bytes.length, bytes);
    // rest already 0
    return result;
  }

  static Uint8List _int32(int v) {
    final bd = ByteData(4);
    bd.setInt32(0, v, Endian.big);
    return bd.buffer.asUint8List();
  }

  static Uint8List _float32(double v) {
    final bd = ByteData(4);
    bd.setFloat32(0, v, Endian.big);
    return bd.buffer.asUint8List();
  }
}
