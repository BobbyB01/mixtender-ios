import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'src/services/osc_service.dart';
import 'src/services/console_state.dart';
import 'src/screens/connection_screen.dart';
import 'src/screens/mix_screen.dart';

void main() {
  runApp(const MixtenderCrossApp());
}

class MixtenderCrossApp extends StatelessWidget {
  const MixtenderCrossApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => OscService()),
        ChangeNotifierProxyProvider<OscService, ConsoleState>(
          create: (context) => ConsoleState(context.read<OscService>()),
          update: (context, osc, previous) =>
              previous ?? ConsoleState(osc),
        ),
      ],
      child: MaterialApp(
        title: 'Mixtender Cross',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF1A1A2E),
            brightness: Brightness.dark,
            primary: const Color(0xFFE94560),
            secondary: const Color(0xFF0F3460),
          ),
          useMaterial3: true,
          scaffoldBackgroundColor: const Color(0xFF0F0F1A),
          appBarTheme: const AppBarTheme(
            backgroundColor: Color(0xFF1A1A2E),
            foregroundColor: Colors.white,
            elevation: 0,
          ),
        ),
        home: const AppRoot(),
      ),
    );
  }
}

class AppRoot extends StatelessWidget {
  const AppRoot({super.key});

  @override
  Widget build(BuildContext context) {
    final osc = context.watch<OscService>();

    if (osc.isConnected || osc.isDemoMode) {
      return const MixScreen();
    }
    return const ConnectionScreen();
  }
}
