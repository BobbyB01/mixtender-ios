package com.mixtender.cross

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
