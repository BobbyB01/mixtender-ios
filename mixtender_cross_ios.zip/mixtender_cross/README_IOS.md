# Mixtender Cross – iOS Build & Private Install Guide

Complete instructions for building and installing **Mixtender Cross** on an iPhone or iPad for personal testing (no App Store required).

---

## 1. Requirements

| Item | Minimum |
|------|---------|
| macOS | 13 Ventura or later recommended |
| Xcode | 15 or later (from Mac App Store) |
| Flutter | 3.16+ stable (`flutter --version`) |
| Apple ID | Free Apple ID is enough for personal device testing |
| Device | iPhone or iPad running iOS 12+ |

---

## 2. Apple Developer account options

### Option A – Free Apple ID (personal testing, 7-day certificates)

1. Use any Apple ID in Xcode.
2. Xcode → Settings → Accounts → add your Apple ID.
3. Signing uses a **Personal Team**.
4. Apps expire after **7 days** and must be re-signed.
5. Limited to devices you register in Xcode.

### Option B – Paid Apple Developer Program ($99/year)

1. Enroll at https://developer.apple.com/programs/
2. Creates development + distribution certificates lasting 1 year.
3. Allows Ad Hoc / TestFlight / App Store distribution.
4. Required if you need longer-lived installs or multiple testers.

For private ProX testing, **Option A is sufficient**.

---

## 3. First-time setup on your Mac

```bash
# 1. Install Flutter if needed: https://docs.flutter.dev/get-started/install/macos

# 2. Unzip the project
unzip mixtender_cross_ios.zip
cd mixtender_cross

# 3. Confirm Flutter sees iOS toolchain
flutter doctor

# 4. Get packages (regenerates Flutter/Generated.xcconfig with your SDK path)
flutter pub get

# 5. Install CocoaPods deps
cd ios
pod install
cd ..
```

If `pod` is missing:

```bash
sudo gem install cocoapods
```

**Important:** Always open `ios/Runner.xcworkspace` (not `.xcodeproj`) after `pod install`.

---

## 4. Signing in Xcode (required for device install)

1. Open the workspace:
   ```bash
   open ios/Runner.xcworkspace
   ```
2. Select the **Runner** project in the left navigator.
3. Select the **Runner** target → **Signing & Capabilities**.
4. Check **Automatically manage signing**.
5. Choose your **Team** (Personal Team or paid team).
6. Set **Bundle Identifier** to something unique, e.g.:
   ```
   com.yourname.mixtendercross
   ```
   (must be unique per Apple ID)
7. Xcode will create a provisioning profile automatically.

If you see “Failed to register bundle identifier”, pick a different unique ID.

---

## 5. Run on a physical iPhone / iPad

1. Connect the device with a cable.
2. Unlock the device and trust the computer if prompted.
3. In Xcode, select your device in the scheme toolbar.
4. Press **Run** (▶) or:
   ```bash
   flutter run -d <device-id>
   ```
   List devices with `flutter devices`.

### Trust the developer on the device (first install)

On the iPhone/iPad:

**Settings → General → VPN & Device Management → [Your Apple ID] → Trust**

---

## 6. Build a release IPA for Ad Hoc / private install

### Using Flutter + Xcode Archive (recommended)

```bash
cd mixtender_cross
flutter build ipa --release
```

Output (when signing is configured):

```
build/ios/ipa/*.ipa
```

### Manual Archive in Xcode

1. `open ios/Runner.xcworkspace`
2. Product → Destination → **Any iOS Device (arm64)**
3. Product → **Archive**
4. Organizer → **Distribute App**
5. Choose **Ad Hoc** (paid team) or **Development** (personal team)
6. Export the `.ipa`

### Install the IPA without App Store

- **Xcode Devices window**: Window → Devices and Simulators → select device → “+” under Installed Apps → choose the `.ipa`
- **Apple Configurator 2** (free from Mac App Store)
- **Finder** (macOS Catalina+): select device → drag IPA
- Third-party tools (AltStore, Sideloadly) for free-team side-loading

---

## 7. Network permissions (already configured)

`ios/Runner/Info.plist` includes:

- `NSLocalNetworkUsageDescription` – required prompt for local network
- `NSBonjourServices` – `_osc._udp` / `_osc._tcp`
- `NSAppTransportSecurity` → `NSAllowsLocalNetworking = true`
- Orientations for iPhone + iPad (portrait & landscape)
- `UIDeviceFamily` = 1,2 (iPhone + iPad)

On first launch iOS will ask: **“Mixtender Cross Would Like to Find and Connect to Devices on Your Local Network”** → Allow.

---

## 8. Connecting to a Midas ProX (or any PRO Series)

1. Connect a Wi-Fi router to the console **Ethernet Control** port.
2. On the console: **Preferences → Configuration → Remote Control Server**
3. Set IP (e.g. `192.168.1.50`) → **START**
4. Join that Wi-Fi network from the iPhone/iPad.
5. Open Mixtender Cross → select **PRO X** → enter IP → **Connect**

Default OSC port: **10002** (confirmed by Midas support for the Remote Control Server).

Demo mode works fully offline for UI testing.

---

## 9. Protocol notes – what is validated vs. what needs console testing

### Used / community-documented (do not invent beyond this)

| Purpose | OSC path pattern | Source |
|---------|------------------|--------|
| Input fader | `/enPPCFaderMessage/enVirtualMicInputs/enFaderLevel/N` | Community RE + Midas support notes |
| Input mute | `/enPPCSwitchMessage/enVirtualMicInputs/enMuteStatus/N` | Same |
| Master fader | `/enPPCFaderMessage/enVirtualMasters/enFaderLevel/N` | Same (L=1,R=2,M=3) |
| Aux/submix fader | `/enPPCFaderMessage/enVirtualSubMixes/enFaderLevel/N` | Community list |
| Meter (request) | `/enPPCMeterMessage/enVirtualMicInputs/enMeter/N` | Community list |
| Channel name string | `/enPPCStringMessage/enVirtualMicInputs/enPathnamePrefix/N` | Community list |

Full endpoint catalogue:  
https://github.com/muffeeee/midas-pro-series-osc-commands

### Requires validation on a real ProX

- Exact meter subscription / keep-alive behaviour
- Full 4-band EQ write addresses for every band parameter
- Gate / compressor parameter addresses
- VCA membership write paths
- GEQ band write paths for DN370 pool
- Scene recall remote commands
- Whether ProX uses identical paths to PRO2 (likely, but unconfirmed on hardware)

The UI models ProX channel counts correctly (144 primary + 24 returns, 99 buses, 10 VCAs, 8 POP).  
Control messages for advanced parameters beyond fader/mute/master should be confirmed against a live desk before show use.

---

## 10. Troubleshooting

| Issue | Fix |
|-------|-----|
| “Signing for Runner requires a development team” | Add Apple ID in Xcode → Settings → Accounts, select Team |
| App installs but won’t open | Trust developer under Settings → General → VPN & Device Management |
| No local network prompt / can’t connect | Delete app, reinstall, tap Allow on the permission dialog |
| `pod install` fails | `sudo gem install cocoapods` then `cd ios && pod install` |
| Flutter can’t find iOS toolchain | `sudo xcode-select -s /Applications/Xcode.app/Contents/Developer` then `flutter doctor` |
| Workspace missing Pods | Run `flutter pub get` then `cd ios && pod install` |

---

## 11. Quick command summary

```bash
cd mixtender_cross
flutter pub get
cd ios && pod install && cd ..
open ios/Runner.xcworkspace
# → set Team + unique Bundle ID → Run on device

# Or from CLI after signing is set up:
flutter run -d <device-id>
flutter build ipa --release
```
