# Mixtender Cross

Cross-platform remote control for **Midas PRO Series** digital mixing consoles  
(compatible with the OSC protocol used by the official **Mixtender 2** iPad app).

Supports: **PRO1, PRO2, PRO2C, PRO3, PRO6, PRO9, PRO X, XL8**

Flutter codebase → native **Android** + **iOS** (iPhone & iPad).

---

## Features

- Console selector with accurate channel/bus counts (ProX: 144+24 inputs / 99 buses)
- Live OSC connection (port 10002) + full Demo mode
- Banked faders, Mute / Solo / Masters
- Full-screen 4-band parametric EQ
- VCA + POP groups with member editing
- 31-band GEQ (DN370 style)
- Live meters (demo animation)
- Safety locks, channel naming & colour
- Scene save / recall
- iPhone + iPad, portrait & landscape

---

## Quick start

```bash
unzip mixtender_cross_ios.zip
cd mixtender_cross
flutter pub get
flutter run          # uses connected device or simulator
```

---

## Android release APK

```bash
flutter build apk --release
# → build/app/outputs/flutter-apk/app-release.apk
```

---

## iOS (iPhone / iPad) – private install

**Full step-by-step guide:** see **[README_IOS.md](README_IOS.md)**

Summary:

```bash
flutter pub get
cd ios && pod install && cd ..
open ios/Runner.xcworkspace
```

1. In Xcode → Runner target → **Signing & Capabilities**
2. Select your **Team** (free Apple ID Personal Team is enough for testing)
3. Set a unique **Bundle Identifier** (e.g. `com.yourname.mixtendercross`)
4. Connect iPhone/iPad → Run ▶
5. On device: **Settings → General → VPN & Device Management → Trust**

Build IPA:

```bash
flutter build ipa --release
```

---

## Console setup

1. Wi-Fi router → console **Ethernet Control** port  
2. Preferences → Configuration → **Remote Control Server** → set IP → START  
3. Join that Wi-Fi from the device  
4. App → select **PRO X** → enter IP → Connect  

---

## Protocol

Community reverse-engineered OSC endpoints (no invented commands):  
https://github.com/muffeeee/midas-pro-series-osc-commands

See README_IOS.md §9 for validated vs. needs-hardware-validation items.

---

## Project layout

```
mixtender_cross/
├── pubspec.yaml
├── lib/                    # Shared Dart app logic
├── android/                # Android project
├── ios/                    # Full iOS / Xcode project
│   ├── Podfile
│   ├── Runner.xcworkspace
│   ├── Runner.xcodeproj/
│   ├── Flutter/
│   └── Runner/
│       ├── Info.plist      # Local network permissions
│       ├── AppDelegate.swift
│       ├── Runner.entitlements
│       └── Assets.xcassets/
├── README.md
└── README_IOS.md           # Signing + install instructions
```

---

**Not affiliated with MUSIC Group / Midas.**  
Test on non-critical systems first.
