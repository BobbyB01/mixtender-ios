import 'package:flutter_test/flutter_test.dart';
import 'package:mixtender_cross/main.dart';

void main() {
  testWidgets('App starts', (WidgetTester tester) async {
    await tester.pumpWidget(const MixtenderCrossApp());
    expect(find.textContaining('Mixtender'), findsWidgets);
  });
}
